import 'package:get/get.dart';
import 'package:squadra_pos/refactor/data/providers/contract.dart';
import 'package:squadra_pos/refactor/data/providers/http/http_contract.dart';
import 'package:squadra_pos/refactor/data/providers/http/http_implementation.dart';
import 'package:squadra_pos/refactor/data/providers/implementation.dart';
import 'package:squadra_pos/refactor/data/resources/local_storage.dart';
import 'package:squadra_pos/refactor/presentation/controllers/auth/c_auto_lock.dart';
import 'package:squadra_pos/refactor/presentation/controllers/auth/c_screen_lock.dart';
import 'package:squadra_pos/refactor/presentation/controllers/auth/c_sign_out.dart';
import 'package:squadra_pos/refactor/presentation/controllers/home/offline/c_print_receipt_offline.dart';

class Dependency extends GetxService {
  static Future<void> init() async {
    // :: Local Storage
    Get.put<LocalStorage>(LocalStorage(), permanent: true);
    // :: Network Initialization
    Get.lazyPut<HttpNetwork>(() => HttpNetworkImplementation(), fenix: true);
    Get.lazyPut<Network>(() => NetworkImplementation(Get.find<HttpNetwork>()),
        fenix: true);
    Get.lazyPut<PrintReceiptOfflineController>(
        () => PrintReceiptOfflineController(Get.find<LocalStorage>()));
    Get.lazyPut<SignOutController>(
        () => SignOutController(Get.find<LocalStorage>()));
    Get.lazyPut<ScreenLockController>(() => ScreenLockController(
        Get.find<LocalStorage>(), Get.find<SignOutController>()));
    Get.put<AutoLockController>(
        AutoLockController(Get.find<ScreenLockController>()),
        permanent: true);
  }
}
