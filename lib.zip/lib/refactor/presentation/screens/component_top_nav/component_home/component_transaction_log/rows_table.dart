import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:recase/recase.dart';
import 'package:squadra_pos/refactor/presentation/routes/app_routes.dart';
import 'package:squadra_pos/refactor/utils/constants.dart';
import 'package:squadra_pos/refactor/utils/custom_formatter.dart';

class RowsTable extends StatelessWidget {
  const RowsTable({required this.data, required this.category, super.key});

  final RxList<dynamic> data;
  final String category;

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Table(
        columnWidths: {
          6: FixedColumnWidth(150.r),
          7: FixedColumnWidth(100.r),
        },
        children: [
          ...data.asMap().entries.map((entry) {
            var index = entry.key;
            var response = entry.value;

            return TableRow(
              decoration:BoxDecoration(
                color: index % 2 == 0? customWhite3 : Colors.white,
              ),
              children: buildTransactionCells(data: response, category: category),
            );
          }),
        ],
      );
    });
  }

  List<TableCell> buildTransactionCells({required dynamic data, required String category}) {
    return [
      _tableTextCell(data.datetime?.toString() ?? "---"),
      _tableTextCell(data.transactionNumber?.toString() ?? "---"),
      _tableTextCell("${data.transactionType ?? '---'} ${data.tableLabel ?? ''}"),
      _tableTextCell(data.customerName?.toString() ?? "---"),
      _tableTextCell(numberFormat('IDR', category == "offline" ? data.subTotal : data.subTotal).toString()),
      _tableTextCell(numberFormat('IDR', category == "offline" ? data.grandTotalAfterTax : data.grandTotalFinal).toString()),
      _statusCell(data.statusTransaction ?? '---'),
      _actionCell(data, category),
    ];
  }

  TableCell _tableTextCell(String text) {
    return TableCell(
      verticalAlignment: TableCellVerticalAlignment.middle,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(text,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 10.sp,
            fontFamily: 'NanumGothic',
            color: customHeadingText,
          ),
        ),
      ),
    );
  }

  TableCell _statusCell(String status) {
    final isClosed = status == TransactionFilter.close.name.titleCase;

    return TableCell(
      verticalAlignment: TableCellVerticalAlignment.middle,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Text(status,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 10.sp,
            fontFamily: isClosed ? 'NanumGothic' : 'UbuntuBold',
            color: isClosed ? customHeadingText : primaryColor,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }

  TableCell _actionCell(dynamic data, String category) {
    return TableCell(
      verticalAlignment: TableCellVerticalAlignment.middle,
      child: InkWell(
        onTap: () {
          if (category == offline) {
            if (data.statusTransaction == TransactionFilter.close.name.titleCase) {
              Get.toNamed(
                RouteName.successPaymentOffline, 
                arguments: {
                  "refresh": false,
                  "transaction_number": data.transactionNumber,
                }
              );
            } else {
              Get.toNamed(
                RouteName.orderOffline, 
                arguments: {
                  "order_type": offline,
                  "table_id": data.tableID,
                  "transaction_number": data.transactionNumber,
                }
              );
            }
          } else {
            Get.toNamed(
              RouteName.orderSM,
              arguments: {
                "unique_number": data.uniqeNumber,
              }
            );
          }
        },
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.all(8.0),
          child: Icon(Icons.receipt, size: 16.sp, color: primaryColor),
        ),
      ),
    );
  }
}