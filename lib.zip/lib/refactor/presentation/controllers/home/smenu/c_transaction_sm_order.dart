import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image/image.dart' as img;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:squadra_pos/database/database_helper.dart';
import 'package:squadra_pos/refactor/data/models/sql_lite/get/sqllite_category/g_category.dart';
import 'package:squadra_pos/refactor/data/models/sql_lite/get/sqllite_menu/g_menu.dart';
import 'package:squadra_pos/refactor/data/models/sql_lite/get/sqllite_station/g_station.dart';
import 'package:squadra_pos/refactor/data/models/transaction_smenu_detail/m_transaction_sm_detail.dart';
import 'package:squadra_pos/refactor/data/resources/local_storage.dart';
import 'package:squadra_pos/refactor/domain/repositories/transactions/smenu/r_smenu.dart';
import 'package:squadra_pos/refactor/presentation/controllers/home/smenu/c_transaction_sm_detail.dart';
import 'package:squadra_pos/refactor/presentation/screens/smenu/component_smenu_order/smenu_reprint_bill.dart';
import 'package:squadra_pos/refactor/utils/custom_formatter.dart';

class TransactionOrderSMController extends GetxController {
  TransactionOrderSMController(this.localStorage, this.sMenuRepository, this.transactionDetailSMController);

  final LocalStorage localStorage;
  final SMenuRepository sMenuRepository;
  final TransactionDetailSMController transactionDetailSMController;

  final dbHelper = DatabaseHelper();
  final pageController = PageController();

  final menuList = <MenuLiteModel>[].obs;
  final menuFilter = <MenuLiteModel>[].obs;
  final categoriesList = <CategoryLiteModel>[].obs;

  final menuImagePath = <int, String>{}.obs;
  final categoryImagePath = <int, String>{}.obs;
  
  final notesFocusNode = FocusNode();
  final notesController = TextEditingController();
  
  final RxMap<String, Set<int>> selectedAddonPerCategory = <String, Set<int>>{}.obs;

  final selectedNoteIndex = RxInt(-1);

  RxInt qtyItemDetail = 1.obs;

  RxString isStaffName = ''.obs;
  RxString isOutletName = ''.obs;

  RxInt isOutletId = 0.obs;
  RxInt isCurrentIndex = 0.obs;
  RxInt isSelectCategory = 0.obs;
  RxBool isWaiters = false.obs;

  var status = RxStatus.empty().obs;

  void createIncrementQty() {
    qtyItemDetail.value++;
  }

  void createDecrementQtyItem() {
    if (qtyItemDetail.value > 1) {
      qtyItemDetail.value--;
    }
  }

  void updateIncrementQty({required int cartDetailId, required int uniqueNumber, String? notes}) async {
    qtyItemDetail.value++; 
    int total = qtyItemDetail.value; 

    await updateItemCall(cartDetailId: cartDetailId, uniqueNumber: uniqueNumber, qty: total);
  }

  void updateDecrementQtyItem({required int cartDetailId, required uniqueNumber, String? notes}) async {
    if (qtyItemDetail.value > 1) {
      qtyItemDetail.value--;
      int total = qtyItemDetail.value;

      await updateItemCall(cartDetailId: cartDetailId, uniqueNumber: uniqueNumber, qty: total);
    }
  }

  bool isAddonSelected(String key, int id) {
    return selectedAddonPerCategory[key]?.contains(id) ?? false;
  }

  void toggleAddon(String key, int id, bool isChecked) {
    selectedAddonPerCategory.update(key,
      (set) {
        final newSet = Set<int>.from(set);
        
        if (isChecked) {
          newSet.add(id);
        } else {
          newSet.remove(id);
        }
        return newSet;
      },
      ifAbsent: () => isChecked ? {id} : <int>{},
    );
  }

  void selectSingleAddon(String key, int id) {
    selectedAddonPerCategory[key] = {id};
  }

  void updateSelectedNoteIndex(int value) {
    selectedNoteIndex.value = value;
  }

  void resetItems() {
    qtyItemDetail.value = 1;
    notesController.clear();
    selectedNoteIndex.value = -1;
    status.value = RxStatus.empty();
    selectedAddonPerCategory.clear();
  }

  void getDataOutlet() async {
    isStaffName.value = await localStorage.getStaffName();
    isOutletId.value = await localStorage.getOutletID();
    isOutletName.value = await localStorage.getOutletName();
  }

  void getMenuLite() async {
    try {
      final results = await dbHelper.getMenu();
    
      menuList.assignAll(results);
      menuFilter.assignAll(results);

      for (var data in results) {
        getPathMenuImage(id: data.menuID);
      }
    } catch (e, stackTrace) {
      throw Exception("Error fetching get menu lite: $e, $stackTrace");
    }
  }

  void getCategoryLite() async {
    final result = await dbHelper.getCategory();

    categoriesList.assignAll(result);

    for (var cat in result) {
      getPathCategoryImage(id: cat.categoryID);
    }
  }
 
  void getMenuFiltered({String? value}) {
    menuFilter.value = menuList.where((response) => response.menuName.toLowerCase().contains(value ?? ''.toLowerCase())).toList();
  }

  void getPathCategoryImage({required int id}) async {
    String? path;

    if (Platform.isAndroid) {
      path = '/data/user/0/com.squadra.squadra_pos/app_flutter/category_image_$id';
    } else if (Platform.isIOS) {
      final directory = await getApplicationDocumentsDirectory();

      path = '${directory.path}/category_image_$id';
    }

    if (path != null) {
      categoryImagePath[id] = path;
    }
  }

  void getPathMenuImage({required int id}) async {
    String? path;

    if (Platform.isAndroid) {
      path = '/data/user/0/com.squadra.squadra_pos/app_flutter/menu_image_$id';
    } else if (Platform.isIOS) {
      final directory = await getApplicationDocumentsDirectory();

      path = '${directory.path}/menu_image_$id';
    }

    if (path != null) {
      menuImagePath[id] = path;
    }
  }

  void handleTabCategory({required int id}) {
    isSelectCategory.value = id;

    if (id == 0) {
      menuFilter.value = menuList;
    } else {
      menuFilter.value = menuList.where((menu) => menu.categoryID == id).toList();
    }
  }

  Future<void> getDataStaff() async {
    String dataStaff = await localStorage.getDataStaff();
    String actionName = await localStorage.getActionName();

    for (var staff in jsonDecode(dataStaff)) {
      String data = staff['AuthLevelID']?['ActionName'];

      if (data.toLowerCase() == "waiters") {
        if (data.toLowerCase() == actionName.toLowerCase()) {
          isWaiters.value = true;
        }
      }
    }
  }

  bool validateSelectedAddons(List<Map<String, dynamic>> addonList) {
    final selectedMap = selectedAddonPerCategory;

    for (var addon in addonList) {
      final String title = addon['title'];
      final bool required = addon['required'] == 1;
      final bool multiply = addon['multiply'] == 1;
      final int min = addon['min'] ?? 1;

      final selected = selectedMap[title] ?? <int>{};

      if (required) {
        if (multiply) {
          // :: Required and can multiply
          if (selected.isEmpty || selected.length < min) return false;
        } else {
          // :: Required but cannot multiply
          if (selected.isEmpty) return false;
        }
      }
    }
    return true;
  }

  List<Map<String, dynamic>> buildSelectedAddOns({required List<Map<String, dynamic>> parsedAddOns, required Map<String, Set<int>> selectedAddonPerCategory}) {
    return parsedAddOns.expand<Map<String, dynamic>>((category) {
      final String categoryTitle = category["title"] ?? "";
      final List<dynamic> menuAddOnList = category["MenuAddOn"] ?? [];

      return menuAddOnList.whereType<Map<String, dynamic>>().where((item) {
        final selectedIDs = selectedAddonPerCategory[categoryTitle];
        final itemID = int.tryParse(item["MenuID"].toString());
        return selectedIDs?.contains(itemID) ?? false;
      }).map((item) {
        final int menuID = int.tryParse(item["MenuID"].toString()) ?? 0;
        final int menuPrice = int.tryParse(item["MenuPrice"].toString()) ?? 0;
        final int menuDiscount = int.tryParse(item["MenuDiscount"].toString()) ?? 0;

        return {
          "menuID": menuID,
          "menuName": item["MenuName"] ?? "",
          "qty": 1,
          "menuPrice": menuPrice,
          "menuPriceAfterDiscount": menuPrice - menuDiscount,
        };
      });
    }).toList();
  }

  Future<void> addToCartCall({required dynamic addOn, required MenuLiteModel menu, required Map<String, dynamic> transaction}) async {
    final parsed = addOn.whereType<Map<String, dynamic>>().toList();
    final isValid = validateSelectedAddons(parsed);

    if (!isValid) {
      status.value = RxStatus.error("Please complete all required fields.");

      return;
    }

    Get.back();

    status.value = RxStatus.empty();

    final addOnList = buildSelectedAddOns(
      parsedAddOns: parsed, 
      selectedAddonPerCategory: selectedAddonPerCategory,
    );

    final outletName = await localStorage.getOutletName();
    
    final Map<String, dynamic> requestBody = {
      "UniqeNumber": transaction["unique_number"],
      "CustomerID": transaction["customer_id"],
      "OutletName": outletName,
      "TableNumber": transaction["table_number"],
      "TransactionType": transaction["transaction_type"],
      "details": [
        {
          "menuID": menu.menuID,
          "menuName": menu.menuName,
          "qty": qtyItemDetail.value,
          "menuPrice": menu.menuPrice,
          "menuPriceAfterDiscount": (menu.menuPrice) - (menu.menuDiscount),
          "Notes": notesController.text,
          "noteOption": "",
          "parentID": menu.menuID,
          "menuImage": menu.menuImage,
          "addOn": addOnList,
        }
      ]
    };

    final result = await sMenuRepository.postAddToCartSM(body: requestBody);

    result.when(
      success: (data, url, headers, statusCode) {
        final status = json.decode(data)['status'];

        if (status == "success") {
          transactionDetailSMController.rebuild(uniqueNumber: transaction["unique_number"]);
        }
      },
      error: (data, url, headers, statusCode) {
        // status.value = RxStatus.error(jsonDecode(data)["message"]);
      },
      failure: (exception) {
        // final response = getContentErrorHTTP(exception);
        
        // status.value = RxStatus.error(response["error_type"]);
      },
    );
  }

  Future<void> removeItemCall({required int cartDetailId, required int uniqueNumber}) async {
    final result = await sMenuRepository.getRemoveCartSM(param: cartDetailId.toString());

    result.when(
      success: (data, url, headers, statusCode) {
        final status = json.decode(data)['status'];

        if (status == "success") {
          transactionDetailSMController.rebuild(uniqueNumber: uniqueNumber);
        }
      },
      error: (data, url, headers, statusCode) {
        // status.value = RxStatus.error(jsonDecode(data)["message"]);
      },
      failure: (exception) {
        // final response = getContentErrorHTTP(exception);
        
        // status.value = RxStatus.error(response["error_type"]);
      },
    );
  }

  Future<void> clearItemCall({required int cartId, required int uniqueNumber}) async {
    final result = await sMenuRepository.getClearCartSM(param: cartId.toString());

    result.when(
      success: (data, url, headers, statusCode) {
        final status = json.decode(data)['status'];

        if (status == "success") {
          transactionDetailSMController.rebuild(uniqueNumber: uniqueNumber);
        }
      },
      error: (data, url, headers, statusCode) {
        // status.value = RxStatus.error(jsonDecode(data)["message"]);
      },
      failure: (exception) {
        // final response = getContentErrorHTTP(exception);
        
        // status.value = RxStatus.error(response["error_type"]);
      },
    );
  }

  Future<void> updateItemCall({int? cartDetailId, required int qty, required int uniqueNumber}) async {
    final requestBody = {
      "cartDetailID": cartDetailId,
      "Notes": notesController.text,
      "Qty": qty
    };

    final result = await sMenuRepository.postUpdateCartSM(body: requestBody);

    result.when(
      success: (data, url, headers, statusCode) {
        final status = json.decode(data)['status'];

        if (status == "success") {
          transactionDetailSMController.rebuild(uniqueNumber: uniqueNumber);
        }
      },
      error: (data, url, headers, statusCode) {
        // status.value = RxStatus.error(jsonDecode(data)["message"]);
      },
      failure: (exception) {
        // final response = getContentErrorHTTP(exception);
        
        // status.value = RxStatus.error(response["error_type"]);
      },
    );
  }

  Future<void> sendOrderCall({required int cartID, required RxList<TransactionSMDetailData> detail, required Rxn<TransactionSMHeaderData> header}) async {
    final requestBody = {
      "cartID": cartID,
      "transactionID": header.value?.transactionID ?? 0
    };

    final result = await sMenuRepository.postSendOrderSM(body: requestBody);

    result.when(
      success: (data, url, headers, statusCode) async {
        final status = json.decode(data)['status'];

        if (status == "success") {
          transactionDetailSMController.rebuild(uniqueNumber: header.value?.uniqueNumber ?? 0);

          await printKitchenCall(header: header, detail: detail);
        }
      },
      error: (data, url, headers, statusCode) {
        // status.value = RxStatus.error(jsonDecode(data)["message"]);
      },
      failure: (exception) {
        // final response = getContentErrorHTTP(exception);
        
        // status.value = RxStatus.error(response["error_type"]);
      },
    );
  }

  Future<void> handlePrintBill(RxList<TransactionSMDetailData> transactionSMDetailList, Rxn<TransactionSMHeaderData> transactionSMFooterData) async {
    final primary = await localStorage.getPrimaryPrinter();

    if (primary.first == 'BluetoothPrinter') {
        await printBillCall(transactionSMDetailList, transactionSMFooterData);
      } else {
        // printBillLan(arguments["transaction_number"], primaryPrinter[1], tableLabel);
      }
  }

  Future<void> printBillCall(RxList<TransactionSMDetailData> transactionSMDetailList, Rxn<TransactionSMHeaderData> transactionSMFooterData) async {
    bool connected = await PrintBluetoothThermal.connectionStatus;
    
    if (!connected) return;

    int totalItem = 0;

    String dateNow = DateFormat("yyyy-MM-dd").format(DateTime.now());
    String timeNow = DateFormat("HH:mm:ss").format(DateTime.now());

    final outletName = await localStorage.getOutletName();
    final outletImage = await localStorage.getImageUrl();
    final staffName = await localStorage.getStaffName();

    final profile = await CapabilityProfile.load();
    final generator = Generator(PaperSize.mm58, profile);

    List<int> bytes = [];

    bytes += generator.reset();

    if (outletImage.isNotEmpty) {
      final Uint8List imageBytes = await File(outletImage).readAsBytes();
      final img.Image? image = img.decodeImage(imageBytes);
      if (image != null) {
        final resizedImage = img.copyResize(image, width: 200);
        bytes += generator.image(resizedImage, align: PosAlign.center);
      }
    }

    bytes += generator.row([
      PosColumn(
        text: 'Bill',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: 'THIS IS NOT RECEIPT',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);

    bytes += generator.hr();
    bytes += generator.row([
      PosColumn(
        text: outletName,
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: '$dateNow $timeNow',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    if ((transactionSMFooterData.value?.tableLabel ?? '').isNotEmpty) {
      bytes += generator.row([
        PosColumn(
          text: 'Table : ${transactionSMFooterData.value?.tableLabel ?? '---'}',
          width: 12,
          styles: const PosStyles(align: PosAlign.center, bold: true),
        ),
      ]);
    }
    bytes += generator.row([
      PosColumn(
        text: transactionSMFooterData.value?.transactionType ?? '---',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: transactionSMFooterData.value?.customerName ?? '---',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.hr();
    // :: List cart
    for (var data in transactionSMDetailList) {
      // final qty = data.qty ?? 0;
      // final decoded = data.discountDetail;

      totalItem += data.qty ?? 0;

      // if (decoded.isNotEmpty) {
      //   for (final discount in decoded) {
      //     if (discount['discountTotal'] != null) {
      //       final int discountTotal = discount['discountTotal'] ?? 0;
            
      //       discountTotalFinal += discountTotal * qty;
      //     }
      //   }
      // }

      bytes += generator.text(
        data.menuName ?? '---',
        styles: const PosStyles(align: PosAlign.left),
      );
      bytes += generator.text(
        formatTwoColumnText(left: '${data.qty} x ${numberFormatNoIDR(data.menuPrice)}', right: numberFormatNoIDR((data.menuPrice ?? 0) * (data.qty ?? 0))),
      );
      // if (data.discountDetail.isNotEmpty) {
      //   bytes += generator.text(
      //     formatTwoColumnText(left: '(Discount)', right: '-${numberFormatNoIDR(data.menuPriceAfterDiscount * data.qty)}'),
      //   );
      // }
      for (var value in data.addOn) {
        bytes += generator.text(
          formatTwoColumnText(left: '- ${value.menuName}', right: numberFormatNoIDR((value.menuPrice ?? 0) * (value.qty ?? 0))),
        );
      }
      // if (data.noteOption.isNotEmpty) {
      //   bytes += generator.text(
      //     'Note Option : ${data.noteOption}',
      //     styles: const PosStyles(align: PosAlign.left),
      //   );
      // }
      if ((data.notes ?? '').isNotEmpty) {
        bytes += generator.text(
          'Notes : ${data.notes}',
          styles: const PosStyles(align: PosAlign.left),
        );
      }
    }
    bytes += generator.feed(1);
    bytes += generator.text(
      formatTwoColumnText(left: 'Subtotal', right: numberFormatNoIDR(transactionSMFooterData.value?.subTotal ?? 0)),
    );
    // if ((discountTotalFinal + transactionList.first.discountTotal) > 0) {
    //   bytes += generator.text(
    //     formatTwoColumnText('Discount Total', numberFormatNoIDR(discountTotalFinal + transactionList.first.discountTotal).toString()),
    //   );
    // }
    if ((transactionSMFooterData.value?.ppn ?? 0) > 0) {
      bytes += generator.text(
        formatTwoColumnText(left: 'PPN', right: numberFormatNoIDR(transactionSMFooterData.value?.ppn ?? 0)),
      );
    }
    bytes += generator.text(
      formatTwoColumnText(left: 'Round', right: numberFormatNoIDR(transactionSMFooterData.value?.rounding ?? 0)),
    );
    bytes += generator.text(
      formatTwoColumnText(left: 'Grand Total', right: numberFormatNoIDR(transactionSMFooterData.value?.grandTotalFinal ?? 0)),
    );
    bytes += generator.text(
      formatTwoColumnText(left: 'Total Due', right: numberFormatNoIDR(transactionSMFooterData.value?.grandTotalFinal ?? 0)),
    );
    bytes += generator.hr();
    bytes += generator.row([
      PosColumn(
        text: '$totalItem Item',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: transactionSMFooterData.value?.transactionNumber ?? '---',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: staffName,
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: 'Your Order',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: '#${(transactionSMFooterData.value?.transactionNumber ?? '').substring((transactionSMFooterData.value?.transactionNumber ?? '').length - 3)}',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.feed(1);
    bytes += generator.row([
      PosColumn(
        text: 'Powered by squadra.id',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.cut();

    await PrintBluetoothThermal.writeBytes(bytes);
  }

  Future<void> printKitchenCall({required RxList<TransactionSMDetailData> detail, required Rxn<TransactionSMHeaderData> header}) async {
    final prefs = await SharedPreferences.getInstance();
    final status = transactionDetailSMController.isPrintBill.value;

    if (status) {
      showDialog(
        context: Get.context!,
        barrierDismissible: true,
        builder: (BuildContext context) {
          return SMReprintBill();
        },
      );
    } else {
      final result = await dbHelper.getStation();
      final primary = await localStorage.getPrimaryPrinter();
      final station = result.map((model) => StationLiteModel.fromJson(model)).toList();

      for (var location in station) {
        String printer = prefs.getString(location.stationName) ?? "";

        if (printer.isNotEmpty) {
          if (printer == 'to Primary') {
            if (primary[0] == 'BluetoothPrinter') {
              printDockets(0, location.stationName, header, detail);
            } else {
              // printDocketLan(0, transactionNumberFinal, primary[1], location.stationID, location.stationName, tableLabel);
            }
          } else {
            // printDocketLan(0, transactionNumberFinal, printer, location.stationID, location.stationName, tableLabel);
          }
        } else {
          debugPrint("Not Connected to Any Printer2");
        }
      }
    }
  }

  Future<void> printDockets(rePrint, stationName, Rxn<TransactionSMHeaderData> header, RxList<TransactionSMDetailData> detail) async {
    bool connected = await PrintBluetoothThermal.connectionStatus;

    if (!connected) return;

    List<int> ticket = await _generateTicket(
      rePrint: rePrint,
      stationName: stationName,
      header: header,
      detail: detail,
    );

    await PrintBluetoothThermal.writeBytes(ticket);
  }

  Future<List<int>> _generateTicket({required int rePrint, String? stationName, required Rxn<TransactionSMHeaderData> header, required RxList<TransactionSMDetailData> detail}) async {
    String dateNow = DateFormat("yyyy-MM-dd").format(DateTime.now());
    String timeNow = DateFormat("HH:mm:ss").format(DateTime.now());

    final profile = await CapabilityProfile.load();
    Generator generator;

    final outletName = await localStorage.getOutletName();
    final staffName = await localStorage.getStaffName();

    generator = Generator(PaperSize.mm58, profile);
    List<int> bytes = [];

    bytes += generator.reset();

    if (rePrint == 1) {
      bytes += generator.row([
        PosColumn(
          text: 'Reprint',
          width: 12,
          styles: const PosStyles(align: PosAlign.center),
        ),
      ]);
    }
    bytes += generator.row([
      PosColumn(
        text: stationName ?? "---",
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.hr();
    bytes += generator.row([
      PosColumn(
        text: outletName,
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: '$dateNow $timeNow',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: 'Table : ${header.value?.tableLabel ?? '---'}',
        width: 12,
        styles: const PosStyles(align: PosAlign.center, bold: true),
      ),
    ]);

    bytes += generator.row([
      PosColumn(
        text: header.value?.transactionType ?? '---',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: header.value?.customerName ?? '---',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);

    for (var cartPrint in detail) {
      bytes += generator.row([
        PosColumn(
          text: '${cartPrint.qty} x ${cartPrint.menuName}',
          width: 12,
          styles: const PosStyles(
            align: PosAlign.left,
            height: PosTextSize.size1,
            width: PosTextSize.size1,
          ),
        ),
      ]);

      bytes += generator.row([
        PosColumn(
          text: '',
          width: 1,
        ),
        PosColumn(
          text: '- ${cartPrint.menuName}',
          width: 11,
          styles: const PosStyles(
            align: PosAlign.left,
            height: PosTextSize.size1,
            width: PosTextSize.size1,
          ),
        ),
      ]);
      if ((cartPrint.notes ?? '').isNotEmpty) {
        bytes += generator.row([
          PosColumn(
            text: '',
            width: 1,
          ),
          PosColumn(
            text: 'Notes : ${cartPrint.notes}',
            width: 11,
            styles: const PosStyles(
              align: PosAlign.left,
              height: PosTextSize.size1,
              width: PosTextSize.size1,
            ),
          ),
        ]);
      }
    }
    bytes += generator.hr();
    bytes += generator.row([
      PosColumn(
        text: '${detail.length} Item',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: header.value?.transactionNumber ?? "---",
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: staffName,
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);

    bytes += generator.feed(2);
    return bytes;
  }

  String formatTwoColumnText({String? left, String? right, int width = 32}) {
    int space = width - (left ?? '').length - (right ?? '').length;

    if (space < 0) space = 1;

    return '$left${' ' * space}$right';
  }

  @override
  void onInit() {
    super.onInit();

    getMenuLite();
    getDataOutlet();
    getDataStaff();
    getCategoryLite();
  }
}