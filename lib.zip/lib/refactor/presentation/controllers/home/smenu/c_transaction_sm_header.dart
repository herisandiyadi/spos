import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:squadra_pos/refactor/data/models/transaction_smenu/m_transaction_sm.dart';
import 'package:squadra_pos/refactor/data/providers/models/api_result.dart';
import 'package:squadra_pos/refactor/data/providers/models/network_exception.dart';
import 'package:squadra_pos/refactor/domain/repositories/transactions/smenu/r_smenu.dart';

class TransactionHeaderSMController extends GetxController {
  TransactionHeaderSMController(this.transactionSMRepository);

  final SMenuRepository transactionSMRepository;

  final transactionSMList = <TransactionSMData>[].obs;

  RxInt totalTransaction = 0.obs;

  var status = RxStatus.empty().obs;

  Timer? _timer;

  Future<void> countTransactionHeaderSMCall() async {
    ApiResult result = await transactionSMRepository.getTransactionSM();

    result.when(
      success: (data, url, headers, statusCode) {
        final response = transactionSMFromJson(data);
        final items = response?.data ?? [];

        totalTransaction.value = items.length;
      },
      error: (data, url, headers, statusCode) async {
        final response = transactionSMFromJson(data);
        final message = response?.status ?? '';

        debugPrint("Error count transaction log smenu: $message");
      },
      failure: (exception) {
        final response = getContentErrorHTTP(exception);

        debugPrint("Error count transaction log smenu: ${response["error_type"]}");
      },
    );
  }

  Future<void> getTransactionHeaderSMCall({bool cron = false}) async {
    if (!cron) status.value = RxStatus.loading();

    await Future.delayed(const Duration(seconds: 1));

    ApiResult result = await transactionSMRepository.getTransactionSM();

    result.when(
      success: (data, url, headers, statusCode) {
        final response = transactionSMFromJson(data);
        final items = response?.data ?? [];

        transactionSMList.value = items;

        status.value = RxStatus.success();
      },
      error: (data, url, headers, statusCode) async {
        final response = transactionSMFromJson(data);
        final message = response?.status ?? '';

        status.value = RxStatus.error(message);
      },
      failure: (exception) {
        final response = getContentErrorHTTP(exception);

        status.value = RxStatus.error(response["error_type"]);
      },
    );
  }

  void rebuild() async {
    await getTransactionHeaderSMCall();

    refresh();
  }

  @override
  void onInit() {
    super.onInit();

    getTransactionHeaderSMCall();
    countTransactionHeaderSMCall();

    _timer = Timer.periodic(const Duration(minutes: 3), (timer) {
      getTransactionHeaderSMCall(cron: true);
    });
  }

  @override
  void onClose() {
    _timer?.cancel();

    super.onClose();
  }
}