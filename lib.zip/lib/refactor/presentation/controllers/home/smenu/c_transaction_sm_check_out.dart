import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:image/image.dart' as img;
import 'package:intl/intl.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:squadra_pos/database/database_helper.dart';
import 'package:squadra_pos/refactor/data/models/sql_lite/get/sqllite_payment_method/g_payment_method.dart';
import 'package:squadra_pos/refactor/data/models/sql_lite/get/sqllite_transaction_type/g_transaction_type.dart';
import 'package:squadra_pos/refactor/data/models/transaction_smenu_detail/m_transaction_sm_detail.dart';
import 'package:squadra_pos/refactor/data/resources/local_storage.dart';
import 'package:squadra_pos/refactor/domain/repositories/transactions/smenu/r_smenu.dart';
import 'package:squadra_pos/refactor/presentation/routes/app_routes.dart';
import 'package:squadra_pos/refactor/utils/custom_dialog.dart';
import 'package:squadra_pos/refactor/utils/custom_formatter.dart';

class TransactionCheckOutSMController extends GetxController {
  TransactionCheckOutSMController(this.sMenuRepository, this.localStorage);

  final SMenuRepository sMenuRepository;
  final LocalStorage localStorage;

  final dbHelper = DatabaseHelper();
  
  final paymentMethod = <PaymentMethodLiteModel>[].obs;
  final transactionTypeJunc = <TransactionTypeLiteModel>[].obs;

  final nominalFocusNode = FocusNode();
  final nominalController = TextEditingController();

  RxInt isPaymentMethodId = 0.obs;
  RxInt isTransactionTypeJuncId = 0.obs;
  RxString isPaymentMethodName = ''.obs;

  var status = RxStatus.empty().obs;

  void _getPaymentMethodLite() async {
    final result = await dbHelper.getPaymentMethodLite();

    paymentMethod.value = result.map((model) => PaymentMethodLiteModel.fromJson(model)).toList();
  }

  void _getTransactionTypeJuncLite() async {
    final transactionType = await dbHelper.getTransactionTypeJuncLite();
   
    transactionTypeJunc.value = transactionType.map((model) => TransactionTypeLiteModel.fromJson(model)).where((item) => item.chargeValue != 0).toList();
  }

  int bulatkanKe500(int harga) {
    return ((harga + 499) ~/ 500) * 500;
  }

  void inputNominal(String number) {
    String currentText = nominalController.text.replaceAll('.', '');
    String text = currentText + number;
    int value = int.tryParse(text) ?? 0;

    nominalController.text = NumberFormat('#,###', 'id_ID').format(value);
  }

  void deleteNominal() {
    String currentText = nominalController.text.replaceAll('.', '');

    if (currentText.isNotEmpty) {
      String text = currentText.substring(0, currentText.length - 1);
      int value = int.tryParse(text) ?? 0;

      nominalController.text = value > 0 ? NumberFormat('#,###', 'id_ID').format(value) : ''; // Format ulang
    }
  }

  Future<void> closeBillCall({required int cartId, required int transactionId, required int amount, required int transactionTypeJuncID, required Map<String, dynamic> arguments, required int tableId}) async {
    final header = arguments['header'] as TransactionSMHeaderData;

    if (isPaymentMethodName.isEmpty) {
      CustomDialog.show(Get.context!, "Please choose the payment type.");
      return;
    }

    final pay = nominalController.text.replaceAll('.', '');

    if (isPaymentMethodName.value == 'Cash') {
      if (pay.isEmpty) {
        CustomDialog.show(Get.context!, "Please enter the cash value.");
        return;
      } else {
        if (num.parse(pay) < (header.grandTotalFinal ?? 0)) {
          CustomDialog.show(Get.context!, "The cash value should be greater than the transaction value.");
          return;
        }
      }
    }

    if (header.transactionType == 'Delivery' && transactionTypeJuncID == 0) {
      CustomDialog.show(Get.context!, "Please choose the delivery type.");
      return;
    }

    status.value = RxStatus.loading();

    await Future.delayed(const Duration(seconds: 1));

    final paymentMethod = [
      {
        "method": isPaymentMethodName.value,
        "amount": amount,
        "pay": pay
      }
    ];

    final requestBody = {
      "cartID": cartId.toString(),
      "transactionID": transactionId.toString(),
      "paymentMethod": paymentMethod,
      "transactionTypeJuncID": isTransactionTypeJuncId.value
    };

    final result = await sMenuRepository.postCheckOutSM(body: requestBody);

    result.when(
      success: (data, url, headers, statusCode) async {
        final status = json.decode(data)['status'];

        if (status == "success") {
          await dbHelper.updateUniqueNumberSM(tableId, 0, '');

          final argumentsExist = Map<String, dynamic>.from(arguments);
          argumentsExist['paymentMethod'] = paymentMethod;

          Get.offNamedUntil(RouteName.successPaymentSM, (route) => route.isFirst, arguments: argumentsExist);

          status.value = RxStatus.success();
        }
      },
      error: (data, url, headers, statusCode) {
        status.value = RxStatus.error();
        // status.value = RxStatus.error(jsonDecode(data)["message"]);
      },
      failure: (exception) {
        status.value = RxStatus.error();
        // final response = getContentErrorHTTP(exception);
        
        // status.value = RxStatus.error(response["error_type"]);
      },
    );
  }

  Future<void> handlePrintReceipt(Map<String, dynamic> args) async {
    final primaryPrinter = await localStorage.getPrimaryPrinter();

    if (primaryPrinter.first == 'BluetoothPrinter') {
      await printReceiptCall(args);
    } else {
      // printReceiptLan(arguments["transaction_number"], primaryPrinter[1], tableLabel ?? '');
    }
  }

  Future<void> printReceiptCall(Map<String, dynamic> args) async {
    String dateNow = DateFormat("yyyy-MM-dd").format(DateTime.now());
    String timeNow = DateFormat("HH:mm:ss").format(DateTime.now());

    final profile = await CapabilityProfile.load();
    Generator generator;

    final outletName = await localStorage.getOutletName();
    final outletImage = await localStorage.getImageUrl();
    final staffName = await localStorage.getStaffName();

    final header = args['header'] as TransactionSMHeaderData?;
    final detail = args['detail'] as List<TransactionSMDetailData>;
    final method = args['paymentMethod'];

    generator = Generator(PaperSize.mm58, profile);
    List<int> bytes = [];

    bytes += generator.reset();

    // if (rePrint == 1) {
    //   bytes += generator.row([
    //     PosColumn(
    //       text: 'Reprint',
    //       width: 12,
    //       styles: const PosStyles(align: PosAlign.center),
    //     ),
    //   ]);
    // }
    if (outletImage.isNotEmpty) {
      final Uint8List imageBytes = await File(outletImage).readAsBytes();
      final img.Image? image = img.decodeImage(imageBytes);
      if (image != null) {
        final resizedImage = img.copyResize(image, width: 200);
        bytes += generator.image(resizedImage, align: PosAlign.center);
      }
    }
    bytes += generator.row([
      PosColumn(
        text: 'Receipt',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.hr();
    bytes += generator.row([
      PosColumn(
        text: outletName,
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: '$dateNow $timeNow',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: 'Table : ${header?.tableLabel ?? '---'}',
        width: 12,
        styles: const PosStyles(align: PosAlign.center, bold: true),
      ),
    ]);

    bytes += generator.row([
      PosColumn(
        text: header?.transactionType ?? '---',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: header?.customerName ?? '---',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);

    for (var items in detail) {
      bytes += generator.text(
        formatTwoColumnText(left: items.menuName),
      );
      bytes += generator.text(
        formatTwoColumnText(left: '${items.qty} x ${numberFormatNoIDR(items.menuPrice)}', right: numberFormatNoIDR((items.menuPrice ?? 0) * (items.qty ?? 0))),
      );
      bytes += generator.text(
        formatTwoColumnText(left: 'Notes', right: items.notes),
      );
    }
    bytes += generator.hr();
    if (method.first['method'] == 'Cash') {
      bytes += generator.text(
        formatTwoColumnText(left: method.first['method'], right: numberFormatNoIDR(method.first["pay"]))
      );
      bytes += generator.text(
        formatTwoColumnText(left: 'Change', right: numberFormatNoIDR((num.tryParse(method.first["pay"]) ?? 0 ) - (header?.grandTotalFinal ?? 0)))
      );
    } else {
      bytes += generator.text(
        formatTwoColumnText(left: 'Payment',  right: method.first['method'])
      );
    }
    bytes += generator.hr();
    bytes += generator.row([
      PosColumn(
        text: '${detail.length} Item',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: header?.transactionNumber ?? "---",
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: staffName,
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: 'Your Order',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.row([
      PosColumn(
        text: '#${(header?.transactionNumber ?? '').substring((header?.transactionNumber ?? '').length - 3)}',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.feed(1);
    bytes += generator.row([
      PosColumn(
        text: 'Powered by squadra.id',
        width: 12,
        styles: const PosStyles(align: PosAlign.center),
      ),
    ]);
    bytes += generator.cut();

    await PrintBluetoothThermal.writeBytes(bytes);
  }

  String formatTwoColumnText({String? left, String? right, int width = 32}) {
    int space = width - (left ?? '').length - (right ?? '').length;

    if (space < 0) space = 1;

    return '$left${' ' * space}$right';
  }

  @override
  void onInit() {
    super.onInit();

    _getPaymentMethodLite();
    _getTransactionTypeJuncLite();
  }
}