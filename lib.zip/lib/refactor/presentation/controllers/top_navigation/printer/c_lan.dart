import 'dart:io';
import 'package:esc_pos_printer/esc_pos_printer.dart';
import 'package:esc_pos_utils/esc_pos_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:image/image.dart' as img;
import 'package:squadra_pos/database/database_helper.dart';
import 'package:squadra_pos/refactor/data/models/sql_lite/get/sqllite_station/g_station.dart';
import 'package:squadra_pos/refactor/data/resources/local_storage.dart';

class LanController extends GetxController {
  LanController(this._localStorage);

  final LocalStorage _localStorage;
  final _dbHelper = DatabaseHelper();

  final ipList = <String>[].obs;
  final information = ''.obs;
  final connectedPrinter = ''.obs;
  final status = RxStatus.empty().obs;

  final selectedPrinters = <int, String?>{}.obs;
  final stations = <StationLiteModel>[].obs;

  @override
  void onInit() {
    super.onInit();

    getPrinterIPDevices();
  }

  void updateSelectedPrinter(
      {required int index,
      required String stationName,
      required String? value}) async {
    selectedPrinters[index] = value;
    selectedPrinters.refresh();

    if (value == null) {
      await _localStorage.removeStationName(stationName);
    } else {
      await _localStorage.saveStationName(stationName, value);
    }
  }

  Future<void> getPrinterIPDevices() async {
    status.value = RxStatus.loading();
    information.value = "Checking Network Printer...";

    await _loadConnectedPrinter();
    final ipPrefix = await _getLocalIpPrefix();

    if (ipPrefix.isEmpty) {
      status.value = RxStatus.error("Failed to get local IP address.");
      return;
    }

    await _scanNetworkPrinters(ipPrefix);
    await _loadStations();
  }

  Future<void> _loadConnectedPrinter() async {
    final primaryPrinter = await _localStorage.getPrimaryPrinter();

    if (primaryPrinter.isNotEmpty && primaryPrinter.first == 'LanPrinter') {
      connectedPrinter.value = primaryPrinter[1];
    }
  }

  Future<String> _getLocalIpPrefix() async {
    for (final interface in await NetworkInterface.list()) {
      for (final addr in interface.addresses) {
        if (addr.type == InternetAddressType.IPv4) {
          final parts = addr.address.split('.');

          return '${parts[0]}.${parts[1]}.${parts[2]}';
        }
      }
    }

    return '';
  }

  Future<void> _scanNetworkPrinters(String ipPrefix) async {
    ipList.clear();

    const port = 9100;
    const concurrency = 20;
    final ips = List.generate(254, (i) => '$ipPrefix.${i + 1}');

    int found = 0;

    for (int i = 0; i < ips.length; i += concurrency) {
      final batch = ips.skip(i).take(concurrency);

      await Future.wait(batch.map((ip) async {
        try {
          final socket = await Socket.connect(ip, port,
              timeout: Duration(milliseconds: 500));
          socket.destroy();
          ipList.add(ip);
          found++;
        } catch (_) {
          // Ignore failures
        }
      }));
    }

    debugPrint('Scan finished. Found $found devices.');
  }

  Future<void> setAsPrimaryPrinter(String ip) async {
    await _localStorage.removeBluetoothPrinter();
    await _localStorage.savePrimaryPrinter(["LanPrinter", ip]);

    connectedPrinter.value = ip;
  }

  Future<void> _loadStations() async {
    final stationData = await _dbHelper.getStation();

    stations
        .assignAll(stationData.map((json) => StationLiteModel.fromJson(json)));

    for (int i = 0; i < stations.length; i++) {
      final printerIp =
          await _localStorage.getStationName(stations[i].stationName);

      if (printerIp.isNotEmpty) {
        final exists = ipList.contains(printerIp);

        selectedPrinters[i] =
            exists || printerIp == 'to Primary' ? printerIp : null;

        status.value = RxStatus.success();
      } else {
        status.value =
            RxStatus.error("No printers detected on the local network.");
      }
    }
  }

  Future<void> connectAndTestPrint(String printerIP) async {
    final profile = await CapabilityProfile.load();
    final printer = NetworkPrinter(PaperSize.mm80, profile);

    final result = await printer.connect(printerIP, port: 9100);

    if (result == PosPrintResult.success) {
      final data = await rootBundle.load('assets/images/logoText.png');
      final bytes = data.buffer.asUint8List();
      // final image = img.decodeImage(bytes);

      // if (image == null) return;

      // printer.image(image);
      printer.text('SQUADRA POS', styles: const PosStyles(bold: true));
      printer.feed(2);
      printer.text('TEST PRINT',
          styles: const PosStyles(align: PosAlign.center));
      printer.feed(2);
      printer.text(
        'TEST PRINT',
        styles: const PosStyles(
            height: PosTextSize.size2, width: PosTextSize.size2),
      );
      printer.feed(1);
      printer.cut();

      printer.disconnect();
    } else {
      status.value =
          RxStatus.error("Failed to connect to printer at $printerIP");
    }
  }
}
