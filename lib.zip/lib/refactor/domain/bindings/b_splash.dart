import 'package:get/get.dart';
import 'package:squadra_pos/refactor/data/resources/local_storage.dart';
import 'package:squadra_pos/refactor/presentation/controllers/c_initial.dart';

class SplashBinding extends Bindings {
  @override
  void dependencies() {    

    // :: Controller
    Get.lazyPut<InitialController>(() => InitialController(Get.find<LocalStorage>()));
  }
}